import { createContext } from "react";

const NoteContex = createContext();

export default NoteContex;